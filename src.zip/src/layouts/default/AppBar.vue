<template>
  <v-app-bar flat>
    <v-app-bar-title>
    </v-app-bar-title>
  </v-app-bar>
</template>

<script setup>
  //
</script>
